#!/bin/bash
ODIR=`pwd`
echo "Exclude= apache* bind-chroot courier* dovecot* exim* httpd* mod_ssl* nsd* php* proftpd* pure-ftpd* spamassassin* squirrelmail*" >> /etc/yum.conf
echo "installonly_limit=2" >> /etc/yum.conf

yum -y install perl wget

sed -i 's/#PermitRootLogin yes/PermitRootLogin no/g' /etc/ssh/sshd_config
sed -i 's/GSSAPIAuthentication yes/GSSAPIAuthentication no/g' /etc/ssh/sshd_config
sed -i 's/#UseDNS yes/UseDNS no/g' /etc/ssh/sshd_config
systemctl enable sshd.service
systemctl restart  sshd.service

yum -y install epel-release
yum -y install ntp policycoreutils-python 

systemctl start ntpd
systemctl enable ntpd 

echo "Disabling useless services."
for i in autofs haldaemon kdump mdmonitor bluetooth avahi-daemon hidd pcscd anacron cups xfs atd nfslock rpcidmapd gpm atd canna cups-config-daemon mDNSResponder nifd rpcidmapd saslauthd avahi-dnsconfd hidd sbadm;do systemctl disable $i.service;done >/dev/null 2>&1

rm -rf /lib/modules/*/kernel/drivers/net/wireless

echo "/var/log/messages /var/log/secure /var/log/maillog /var/log/spooler /var/log/cron /var/log/kern.log /var/log/daemon.log /var/log/syslog {" > /etc/logrotate.d/syslog
echo "    sharedscripts" >> /etc/logrotate.d/syslog
echo "    postrotate" >> /etc/logrotate.d/syslog
echo "	/bin/kill -HUP \`cat /var/run/syslogd.pid 2> /dev/null\` 2> /dev/null || true" >> /etc/logrotate.d/syslog
echo "    endscript" >> /etc/logrotate.d/syslog
echo "}" >> /etc/logrotate.d/syslog

echo "*               hard      core	        0" >> /etc/security/limits.conf 

authconfig --enablepamaccess --updateall

chown root:root ../scripts/db_backup.sh

#TARKISTA SEURAAVA  (Ei tarvitse sovelluskartanoissa)
#chown root:root mysqloptimize.sh
#chmod 700 mysqloptimize.sh 
cp mysqloptimize.sh /usr/local/sbin/

cat <<EOF >> /etc/crontab
5 1 1 * *   root /usr/local/sbin/mysqloptimize.sh >/dev/null 2>&1
EOF

groupadd -g 503 infra

mkdir -p /home/infra

for i in  mamun paulik aril;do useradd -G infra,wheel -b /home/infra $i;done

#tommin ja steffen passut kuntoon
sed -i 's#paulik:!!:#paulik:$6$Y4i56GQV$LhNs6OA3LeQutmDRQ3W9UvQcsqpr4homeNgt9zZJhArvO7TBKpAMKJ0UKdqaqWPDCDjuceSalv.X5kOkMuHcT/:#g' /etc/shadow
sed -i 's#aril:!!:#aril:$6$nO2pZDW7$31Dl6XzOYk4DaoZHF63oOaCl9CQyKlPucI2HkXFhvPfWheLXJE8Op/igmIRYR6pUu5A0Ge3riiXf2JJH79SID0:#g' /etc/shadow

sh ssh-keys.sh

cat <<EOF >> /etc/sudoers
%infra ALL=(ALL) ALL
EOF

cat <<EOF >> /etc/ssh/sshd_config
Match Group infra
    PasswordAuthentication no
EOF

sed -i 's/*.emerg/#*.emerg/g' /etc/rsyslog.conf
systemctl restart rsyslog

echo "REMEMBER TO SET YOUR PASSWORD BEFORE REBOOTING!"


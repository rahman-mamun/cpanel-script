#!/bin/bash
mysqlcheck -u root -s -A -o

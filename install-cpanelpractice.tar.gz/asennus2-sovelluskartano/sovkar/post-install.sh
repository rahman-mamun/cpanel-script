#!/bin/bash

ODIR=`pwd`
cd /var/log
chmod o-rwx *

cd $ODIR

mkdir -p /etc/cpanel/ea4/profiles/custom/
/bin/cp -f ../conf/sovelluskartano_profile.json /etc/cpanel/ea4/profiles/custom/

/bin/cp -f ../packages/* /var/cpanel/packages/
/bin/cp -f ../features/* /var/cpanel/features/

chmod 644 /var/cpanel/packages/*
chmod 644 /var/cpanel/features/*

#Asennetaan CSF & LFD
wget https://download.configserver.com/csf.tgz 
wget https://download.configserver.com/cmq.tgz
wget https://download.configserver.com/cmm.tgz
tar -zxf csf.tgz
tar -zxf cmm.tgz
tar -zxf cmq.tgz
cd cmm
sh install.sh
cd $ODIR
cd cmq
sh install.sh
cd $ODIR
cd csf
sh install.sh
cd $ODIR
chown root:root csf.*
/bin/cp -f /root/asennus2-sovelluskartano/conf/csf.* /etc/csf/

/usr/local/bin/ea_install_profile --install /etc/cpanel/ea4/profiles/custom/sovelluskartano_profile.json

/bin/cp -f /opt/cpanel/ea-php72/root/etc/php.ini /opt/cpanel/ea-php72/root/etc/php.ini.original
/bin/cp -f ../conf/php.ini.ea-php72 /opt/cpanel/ea-php72/root/etc/php.ini

sed -i 's/^PassivePortRange .*$/PassivePortRange 32768 65534/' /etc/pure-ftpd.conf

# Asennetaan Installatron
wget https://data.installatron.com/installatron-plugin.sh
chmod +x installatron-plugin.sh
./installatron-plugin.sh -f
echo "domaincheck=no" >> /usr/local/installatron/etc/settings.ini 

# Asennetaan WP-CLi

curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar
chmod +x wp-cli.phar
mv wp-cli.phar /usr/local/bin/wp
mv ../conf/wpcli.cfg /etc/cagefs/conf.d/

# Quic päälle ja /hallinta osoitteet toimimaan
cat <<EOF >> /usr/local/apache/conf/includes/pre_main_global.conf
<IfModule LiteSpeed>
CacheRoot /home/lscache/
</IfModule>
<IfModule LiteSpeed>
  QuicEnable on
</IfModule>
ScriptAliasMatch ^/?hallinta/?$ /usr/local/cpanel/cgi-sys/redirect.cgi
EOF

/usr/local/cpanel/bin/apache_conf_distiller --update
/scripts/rebuildhttpdconf




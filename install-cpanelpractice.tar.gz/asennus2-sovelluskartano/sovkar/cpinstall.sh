#!/bin/bash

yum -y remove subscription-manager
systemctl stop NetworkManager.service
systemctl disable NetworkManager.service

cd /home
curl -O https://securedownloads.cpanel.net/latest
sh latest
